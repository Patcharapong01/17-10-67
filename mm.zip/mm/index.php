<?php
    include('header.php');
    include('main-menu.php');
    include('footer.php');
?>